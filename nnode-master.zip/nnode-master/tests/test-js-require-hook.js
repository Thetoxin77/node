require('../index');
require('./test-js-features');
