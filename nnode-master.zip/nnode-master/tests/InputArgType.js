"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var fs_1 = require("fs");
var InputArgType = /** @class */ (function () {
    function InputArgType() {
    }
    return InputArgType;
}());
exports.InputArgType = InputArgType;
console.log('readFileSync', fs_1.readFileSync);
